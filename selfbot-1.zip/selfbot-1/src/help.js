const q = '```'
const y = '_'
const f = '*'
const c = '~'
const help = (prefix) => {
	return  `┌──「 𝙎𝙀𝙇𝙁 𝘽𝙊𝙏 」───
│
├ ${f}${prefix}sticker${f}
├ ${f}${prefix}stickergif${f}
├ ${f}${prefix}stickerwa${f}
├ ${f}${prefix}textmaker teks atas|teks bawah${f}
├ ${f}${prefix}attp${f}
├ ${f}${prefix}ttp${f}
├ ${f}${prefix}take${f}
├ ${f}${prefix}tovideo${f}
├ ${f}${prefix}toimg${f}
│
├ ${f}${prefix}runtime${f}
├ ${f}${prefix}ping${f}
├ ${f}${prefix}term${f}
├ ${f}${prefix}blocklist${f}
├ ${f}${prefix}run${f}
├ ${f}${prefix}chatlist${f}
├ ${f}${prefix}owner${f}
│
├ ${f}${prefix}hidetag Text${f}
├ ${f}${prefix}stctag Tag Stc${f}
├ ${f}${prefix}imgtag Tag Img${f}
├ ${f}${prefix}kontag Text${f}
├ ${f}${prefix}kontak 6281xxx Nama${f}
│
├ ${f}${prefix}setreply${f}
├ ${f}${prefix}setwelcome${f}
├ ${f}${prefix}setleave${f}
├ ${f}${prefix}setpromote${f}
├ ${f}${prefix}setdemote${f}
│
├ ${f}${prefix}upswtext${f}
├ ${f}${prefix}upswimg${f}
├ ${f}${prefix}upsvideo${f}
│
├ ${f}${prefix}welcome 1/0${f}
├ ${f}${prefix}linkgroup${f}
├ ${f}${prefix}group tutup/buka${f}
├ ${f}${prefix}add 6281xxx${f}
├ ${f}${prefix}kick @tag${f}
├ ${f}${prefix}promote @tag${f}
├ ${f}${prefix}demote @tagadmin${f}
├ ${f}${prefix}edotensei @tag${f}
├ ${f}${prefix}listadmin${f}
├ ${f}${prefix}online${f}
├ ${f}${prefix}infoall${f}
├ ${f}${prefix}notif${f}
│
├ ${f}${prefix}addstik Optional${f}
├ ${f}${prefix}adimg Optional${f}
├ ${f}${prefix}addvid Optional${f}
├ ${f}${prefix}addvn Optional${f}
├ ${f}${prefix}getstik Query${f}
├ ${f}${prefix}getimg Query${f}
├ ${f}${prefix}getvid Query${f}
├ ${f}${prefix}gervn Query${f}
├ ${f}${prefix}liststick${f}
├ ${f}${prefix}listimg${f}
├ ${f}${prefix}listvid${f}
├ ${f}${prefix}listvn${f}
│
├ ${f}${prefix}asupan${f}
├ ${f}${prefix}asupanamel${f}
├ ${f}${prefix}asupanrana${f}
├ ${f}${prefix}asupankaika${f}
├ ${f}${prefix}asupannuna${f}
│
├ ${f}${prefix}play${f}
├ ${f}${prefix}ig${f}
├ ${f}${prefix}fb${f}
├ ${f}${prefix}tiktok${f}
├ ${f}${prefix}ytmp3${f}
├ ${f}${prefix}ytmp4${f}
│
└──「 𝙕𝙄𝙏𝙎𝙍𝘼𝘼 𝙎𝙀𝙇𝙁 」───`


}

exports.help = help
